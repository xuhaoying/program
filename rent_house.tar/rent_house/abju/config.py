
HEADERS = {
	"User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}

# area:page  地区：页数
AREA = {'xiaoshan': 50,'binjiangb': 50,'xihu': 50,
		'linan': 8,'yuhang': 50,'jianggan': 50,'gongshu': 50,
		'shangcheng': 50,'fuyang': 19,'xiacheng': 50}
URL = "https://hz.zu.anjuke.com/fangyuan/{}/p{}/"
